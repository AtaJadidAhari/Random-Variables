
#' a package for generatint Random Variables, with a rather enhanced random generator 
#' than R's built in methods.
