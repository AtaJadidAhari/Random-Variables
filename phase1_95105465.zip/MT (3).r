require("bitops")


MT <-setClass(
  "MT",
  
  #slots
  slots = c(
    seed = "numeric",
    next_ = "numeric",
    state = "numeric"
  ),
  
  prototype = list(
    seed = 5489,
    state = vector("numeric", 624),
    next_ = 0
  )
)

setGeneric(name = "init",
           def = function(this){
             standardGeneric("init")
           }
)

setMethod(f="init",
          signature = "MT",
          definition = function(this){
            this@state[1] = this@seed;
            temp = 0
            testVec <- c()
            for (i in 2:624) {
              s = bitXor(this@state[i - 1], bitShiftR(this@state[i - 1], 30));
              temp = bitAnd(s, 0xffff0000)
              temp = bitShiftR(temp, 16)
              temp = temp * 1812433253
              a = binary(temp, testVec)
              temp = binaryVevtor_toNumber(a)
              temp = bitShiftL(temp, 16)
              temp = temp + bitAnd(s, 0x0000ffff) * 1812433253
              a = binary(temp, testVec)
              temp = binaryVevtor_toNumber(a)
              temp = temp + i - 1
              this@state[i] = temp
              
            }
            
            this <- twist(this)
            return(this)
          }
)


setGeneric(name = "twist",
           def = function(this){
             standardGeneric("twist")
           }
)

setMethod(f="twist",
          signature = "MT",
          definition = function(this){
            temp1 = 0
            temp2 = 0
            for(i in 1:227){
              bits = bitOr(bitAnd(this@state[i] , 0x80000000), bitAnd(this@state[i + 1] , 0x7fffffff));
              temp1 = bitXor(this@state[i + 397], (bits / 2));
              temp2 = bitAnd(bits, 1) * 0x9908b0df
              this@state[i] = bitXor(temp1, temp2)
            } 
            for(i in 228:623){
              bits = bitOr(bitAnd(this@state[i] , 0x80000000), bitAnd(this@state[i + 1] , 0x7fffffff));
              temp1 = bitXor(this@state[i - 227], (bits / 2));
              temp2 = bitAnd(bits, 1) * 0x9908b0df
              this@state[i] = bitXor(temp1, temp2)
            }
            bits = bitOr(bitAnd(this@state[624] , 0x80000000), bitAnd(this@state[1] , 0x7fffffff));
            temp1 = bitXor(this@state[397], (bits / 2));
            temp2 = bitAnd(bits, 1) * 0x9908b0df
            this@state[624] = bitXor(temp1, temp2)
            this@next_ = 1
            return(this)
          }
)

setGeneric(name = "random",
           def = function(this){
             standardGeneric("random")
           }
)


setMethod(f="random",
          signature = "MT",
          definition = function(this){
            x = this@state[this@next_]
            x = bitXor(x, bitShiftR(x, 11))
            x = bitXor(x, bitAnd(0x9d2c5680, bitShiftL(x, 7)))
            x = bitXor(x, bitAnd(0xefc60000, bitShiftL(x, 15)))
            x = bitXor(x, bitShiftR(x, 18))
            return(x)            
          }
)


rgenerator <- function(seed, numOfReapeat){
  mt <- MT(seed=seed)
  mt <- init(mt)
  res <- c()
  for(i in 1:numOfReapeat){
    res <- c(res, random(mt))
    mt@next_ = mt@next_ + 1
    if(mt@next_ >= 625){
      mt <- twist(mt)
    }
  }
  return(res)
}

dugen <- function(n, min, max) {
  v <- min + rgenerator(seed = as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31), numOfReapeat = n) * (max - min) / 4294967296.0
}

cugen <- function(n){
  v <- rgenerator(seed = as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31), numOfReapeat = n) / 4294967296.0 
}

int_to_unit <- function (x, adjustment=2^32) {
  x <- as.numeric(x)
  signs <- sign(x)
  x[signs < 0] <- x[signs < 0] + adjustment
  x
}


binary <- function(n, seqVecor){
  if(length(seqVecor) == 64){
    return (seqVecor)
  }
  else{
    seqVecor <- c(seqVecor, n %% 2)
    n = floor(n / 2)
    binary(n,seqVecor)
  }
}

binaryVevtor_toNumber <- function(vec){
  res = 0
  for(i in 1:32){
    res = res + vec[i] * (2 ** (i - 1))
  }
  return(res)
}

plotUniform <-function(n, min, max) {
  v <- dugen(n, min, max)
  ggplot(data.frame(v),aes(v)) + geom_density()
}

histUniform <- function(n, min, max){
  v <- dugen(n, min, max)
  hist(v)
}