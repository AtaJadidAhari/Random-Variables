gagen=function(number,k,landa){
  answer=c()
  for(i in 1:number){
    answer=c(answer,sum(expgen(k,landa)))
  }
  return(answer)
}

gaplot=function(number,k,landa){
  library(ggplot2)
  x=gagen(number,k,landa)
  ggplot(data.frame(x),aes(x))+geom_density()
}