expgen=function(landa,number=1){
  rand=cugen(number)# replace cugen
  answer=c()
  for(i in 1:number){
    answer=c(answer,-log(rand[i])/landa)
  }
  return(answer)
}

expplot=function(landa,number=1){
  
  library(ggplot2)
  x=expgen(number,landa)
  ggplot(data.frame(x),aes(x))+geom_density()
}