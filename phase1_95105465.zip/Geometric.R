#floor(ln(u)/ln(1-p) )

geometric <- function(p){
  u <- cugen(1)
  floor(log(u)/log(1 - p))
}



gegen <- function(p){
  sum <- 0
  while(TRUE){
    u <- brgen(p)
    if(u == 0){
      sum <- sum + 1
    }
    else{
      return(sum)
    }
  }
}
plotGeo <- function(numbers, p){
  library(ggplot2)
  vec <- vector()
  for(i in 1:numbers){
    vec[i] <- geometric(p)
  }
  ggplot(data.frame(vec),aes(x=vec)) + geom_density()
}

