pogen <- function(lambda, t){
  if(t == 0){
    return(0)
  }
  nums <- 0
  time <- 0
  while(time < t){
    time <- time + expgen(lambda, 1)
    nums <- nums + 1
  }
  
  return(nums - 1)
  
}

plotPo <- function(numbers, lambda, t){
  library(ggplot2)
  vec <- vector()
  for(i in 1:numbers){
    vec[i] <- pogen(lambda, t)
  }
  ggplot(data.frame(vec),aes(x=vec)) + geom_density()
}