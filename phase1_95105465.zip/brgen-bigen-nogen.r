brgen <- function(p){
    x <- cugen(1)

    if(x <= p)
        return(0)
    else
        return(1)
}

brgenPlot <- function(simulations, p){
    x <- replicate(simulations, brgen(p))

    hist(x)
}


bigen <- function(n, p){


    res = 0

    for(i in 1:n){
        res = res + brgen(p)
    }

    return(res)
}


bigenPlot <- function(simulations, n, p){
    x <- replicate(simulations, bigen(n,p))

    hist(x)
}


nogen <- function(u, s){
  x <- rpois(1, 100000) #it has to be changed to pogen(1, 1000000)
  x = x - 100000
  x = x * sqrt(s)
  x = x + u

  
  return(x)
}


nogenPlot <- function(simulations, u, s){

    library(ggplot2)

    x <- replicate(simulations, nogen(u, s))

    ggplot(data.frame(x),aes(x)) + geom_density()

    # or : 
    # q <- density(x) 
    # plot(q)

}
